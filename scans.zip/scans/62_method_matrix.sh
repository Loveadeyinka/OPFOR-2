#!/bin/bash
TARGET="192.168.163.134"
METHODS="GET HEAD POST PUT DELETE OPTIONS TRACE CONNECT PATCH PROPFIND PROPPATCH MKCOL COPY MOVE LOCK UNLOCK"
PATHS="/ /gitweb/ /phpMyAdmin/ /cgi-bin/ /cgi-bin/test.cgi /server-status /images/ /addon-modules/ /icons/"

for path in $PATHS; do
  echo "===== PATH: $path ====="
  for method in $METHODS; do
    code=$(curl -s -o /dev/null -w "%{http_code}" -X $method "http://$TARGET$path" --max-time 5)
    printf "%-10s %s\n" "$method" "$code"
  done
  echo ""
done
